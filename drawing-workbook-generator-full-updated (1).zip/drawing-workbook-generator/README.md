# Drawing Workbook Generator

A small Streamlit app for turning one or more reference images into printable black-and-white drawing-practice workbooks.

The idea is to make the transition from highly structured drawing exercises to more independent drawing **gradual rather than abrupt**. The same perceptual skills can be repeated across increasingly complex references while placement support fades in stages.

![App overview](assets/app_overview.png)

## What the generator can make

For each uploaded image you can choose any combination of:

1. **Blind contour** — no grid; observation only
2. **Regular contour** — no grid; observation only
3. **SAM / mapping** — sighting, angles, and mapping with scaffold support
4. **Upside-down drawing** — reduces object-labeling while keeping placement support
5. **Negative space** — draw the empty shapes around and between forms
6. **3-value study** — simplify the image into dark, middle, and light
7. **5-value study** — a more developed value plan
8. **Progressive focus** — work on one evolving drawing from very blurred to sharp
9. **Integrated study** — combine the process with only a light center-cross scaffold

The supported exercises can be generated as both compact same-page studies and larger practice pages.

## Why the grids change

The scaffold is deliberately reduced in stages instead of disappearing all at once:

**fine grid → medium grid → coarse grid → center cross**

That makes it possible to change one source of difficulty at a time.

![Grid scaffold progression](assets/scaffold_progression.jpg)

## Example: contour exercises

Blind contour and regular contour are treated as observation exercises, so they intentionally do **not** use a grid.

![Contour example](assets/contour_example.jpg)

## Image input

The app accepts **PNG, JPG/JPEG, and WEBP** files through drag-and-drop or the file browser.

It also accepts images directly from the clipboard. On Windows, for example, use **Win + Shift + S** to make a screen clipping, then click **Paste screenshot/image from clipboard** in the app. The screenshot is imported as PNG, so it does not need to be saved as a file first. Multiple clipboard images can be added one after another.

Clipboard access depends on the browser Clipboard API. Hosted Streamlit apps use HTTPS, which is the secure context browsers normally require for clipboard access.

## Image framing

Each reference image can use one of three framing modes:

- **Auto frame** — trims obvious unused outer background before sizing the exercise boxes
- **Crop manually** — interactive draggable/resizable crop box, with free or fixed aspect ratios
- **Use full image exactly** — preserves the complete uploaded image and its existing whitespace

A manually approved crop is used consistently for every derived exercise.

## Multiple images and downloads

You can upload several reference images at once and choose different exercises for each.

Output options:

- **One merged workbook** — all selected images in one PDF
- **Separate workbook for each image** — one PDF per reference
- **Both** — merged PDF plus separate PDFs

Separate workbooks can also be downloaded together as a ZIP. Download names include the uploaded image filename so repeated generations are easier to distinguish.

## Print layout

The app supports two print layouts:

- **Duplex - facing pages (recommended)** — larger exercises are arranged so the reference lands on the left page and the drawing page faces it on the right when printed double-sided.
- **Single-sided / no duplex adjustments** — pages are generated in straightforward sequence without parity correction.

For **progressive focus**, duplex mode uses a duplex-safe spread layout: each blur stage gets its own facing working page. This avoids having a reference printed on the back of a page you are meant to draw on. If you specifically want one single evolving physical drawing sheet, use the single-sided layout for that section or work on a separate loose sheet while using the printed reference pages.

## Output

PDFs are generated directly in Python with ReportLab. No LibreOffice or Word installation is required.

The generator:

- derives drawing-box proportions from the actual reference image
- keeps matching reference/drawing areas at the same aspect ratio
- supports compact and large-study versions
- creates grids relative to the image proportions rather than forcing every image into a fixed 5×7 frame
- keeps the entire workflow black-and-white for now

## Run locally

### 1. Clone the repository

GitHub Desktop is the easiest option if you do not use Git from the command line regularly.

### 2. Open a command window in the repository folder

In File Explorer, open the repo folder, click the address bar, type:

```text
cmd
```

and press Enter.

### 3. Install dependencies

```bat
python -m pip install -r requirements.txt
```

### 4. Run the app

```bat
python -m streamlit run workbook_generator_app.py
```

The app should open automatically in your browser.

## Streamlit Cloud

This repository can also be deployed on Streamlit Community Cloud using `workbook_generator_app.py` as the entry point. Once deployed, pushing updates to the GitHub repository will trigger a redeploy automatically.

## Repository files

- `workbook_generator_app.py` — Streamlit user interface
- `workbook_generator_backend.py` — image processing and direct PDF generation
- `example_build.py` — small programmatic example
- `requirements.txt` — Python dependencies
- `assets/` — screenshots used in this README

## Current design philosophy

The workbook process is intentionally repetitive. A learner can practice the **same skill several times on the same image**, then use the same process on a more complex image. The goal is to build a repeatable approach to new subjects rather than jump from a constrained exercise directly to an unsupported blank page.

## Possible next steps

- reorder uploaded images before generation
- save/load exercise settings as a preset
- estimate page count before generating
- per-image presets such as “simple object,” “organic form,” and “full study”
- later: optional color-study exercises
